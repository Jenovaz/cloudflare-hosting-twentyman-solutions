"use client";

import { FormEvent, useState } from "react";

export function QuoteForm() {
  const [notice, setNotice] = useState("");

  function submitQuote(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const subject = `Free quote request — ${form.get("suburb") || "Sydney"}`;
    const body = [
      `Name: ${form.get("name") || ""}`,
      `Phone: ${form.get("phone") || ""}`,
      `Email: ${form.get("email") || ""}`,
      `Suburb: ${form.get("suburb") || ""}`,
      `Service: ${form.get("service") || ""}`,
      `Property: ${form.get("property") || ""}`,
      `Frequency: ${form.get("frequency") || ""}`,
      `Preferred timing: ${form.get("timing") || ""}`,
      "",
      "Priorities / extra information:",
      `${form.get("details") || ""}`,
    ].join("\n");
    window.location.href = `mailto:twentyman.solutions@gmail.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    setNotice("Your email app should now open with the quote details ready to send.");
  }

  return (
    <form className="quote-form" onSubmit={submitQuote}>
      <div className="field-grid">
        <label>Full name<input name="name" autoComplete="name" required /></label>
        <label>Contact number<input name="phone" type="tel" autoComplete="tel" required /></label>
        <label>Email address<input name="email" type="email" autoComplete="email" required /></label>
        <label>Suburb<input name="suburb" autoComplete="address-level2" required /></label>
        <label>Service required
          <select name="service" required defaultValue="">
            <option value="" disabled>Select a service</option>
            <option>Regular weekly cleaning</option>
            <option>Regular fortnightly cleaning</option>
            <option>One-off general clean</option>
            <option>Deep clean</option>
            <option>Move-in or move-out clean</option>
            <option>Home assistance</option>
            <option>Other / not sure</option>
          </select>
        </label>
        <label>Property
          <select name="property" required defaultValue="">
            <option value="" disabled>Choose property size</option>
            <option>Apartment / studio</option>
            <option>1–2 bedroom home</option>
            <option>3 bedroom home</option>
            <option>4 bedroom home</option>
            <option>5+ bedroom home</option>
          </select>
        </label>
        <label>Preferred frequency
          <select name="frequency" required defaultValue="">
            <option value="" disabled>Choose frequency</option>
            <option>Weekly</option>
            <option>Fortnightly</option>
            <option>Monthly</option>
            <option>One-off</option>
            <option>Not sure yet</option>
          </select>
        </label>
        <label>Preferred day or time<input name="timing" placeholder="e.g. Tuesday afternoon" /></label>
      </div>
      <label>Cleaning priorities or extra information
        <textarea name="details" rows={6} placeholder="Tell us about the condition, priority areas, pets, access or any specific tasks." />
      </label>
      <p className="form-helper">Your details stay on your device and an email is prepared for you to review before sending.</p>
      <button className="button button-primary" type="submit">Prepare my quote request</button>
      {notice && <p className="form-notice" role="status">{notice}</p>}
    </form>
  );
}
